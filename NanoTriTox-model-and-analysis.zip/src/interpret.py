"""Run dose/time or grouped SHAP using only the frozen model.

Inputs are the study website's standardized development_oof/internal_test CSVs.
"""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import numpy as np
from postfit import clean, matched_response, grouped_shap

class FrozenPredictor:
    def __init__(self):
        self.process=subprocess.Popen([os.environ.get('NANOTRITOX_NODE','node'),str(Path(__file__).with_name('run.mjs')),'serve'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,encoding='utf-8')
        self.meta=self.call({'op':'metadata'})
    def call(self,obj):
        self.process.stdin.write(json.dumps(clean(obj),allow_nan=False)+'\n');self.process.stdin.flush()
        line=self.process.stdout.readline()
        if not line: raise RuntimeError('Frozen-model process stopped')
        answer=json.loads(line)
        if 'error' in answer: raise RuntimeError(answer['error'])
        return answer['result']
    def __call__(self,samples):
        return np.asarray(self.call({'op':'predict','features':[s['features'] for s in samples]}))
    def close(self):
        self.process.stdin.close();self.process.wait()

def load_samples(path,predict):
    with open(path,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    features=predict.call({'op':'features','rows':rows})
    samples=[]
    for row,feat in zip(rows,features):
        for k in predict.meta['numeric']:
            if feat[k] is None:feat[k]=np.nan
        mask=np.array([row.get(f'E{j}_label','')!='' for j in (1,2,3)])
        samples.append({'sample_id':row['sample_id'],'source':row['source_dataset'],'group':row['material_group'],'material':row['material_name'],'dose':float(row['dose_ug_ml']),'time_h':float(row['exposure_time_h']),'features':feat,'mask':mask,'y':np.array([float(row[f'E{j}_label']) if mask[j-1] else np.nan for j in (1,2,3)])})
    return samples

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('analysis',choices=['dose','time','shap']);p.add_argument('development');p.add_argument('internal');p.add_argument('output');a=p.parse_args()
    predictor=FrozenPredictor()
    try:
        state={'dev':load_samples(a.development,predictor),'internal':load_samples(a.internal,predictor),'ELEMENTS':predictor.meta['elements'],'NUMERIC':predictor.meta['numeric'],'CATEGORICAL':predictor.meta['categorical']}
        state['internal_ens']=predictor(state['internal'])
        out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
        if a.analysis=='shap':grouped_shap(state,predictor,out)
        else:matched_response(state,predictor,out,a.analysis)
    finally:predictor.close()
