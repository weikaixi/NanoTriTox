"""Original post-fit numerical analysis; training and plotting removed.

Grouped interventional Shapley paths and matched-series rules are unchanged.
"""
import csv
import json
from collections import defaultdict
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import accuracy_score, average_precision_score, balanced_accuracy_score, matthews_corrcoef, roc_auc_score
SEED=20260906
HEADS=['E1','E2','E3']
def clean(value):
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (int, np.integer)):
        return int(value)
    return value

def write_json(path, obj):
    path.write_text(json.dumps(clean(obj), ensure_ascii=False, indent=2), encoding='utf-8')

def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def metric(y, p):
    pred = p >= 0.5
    both = len(np.unique(y)) == 2
    return {'accuracy': accuracy_score(y, pred), 'balanced_accuracy': balanced_accuracy_score(y, pred) if both else np.nan, 'mcc': matthews_corrcoef(y, pred) if both and len(np.unique(pred)) == 2 else np.nan, 'roc_auc': roc_auc_score(y, p) if both else np.nan, 'pr_auc': average_precision_score(y, p) if both else np.nan}

def feature_key(sample, exclude):
    return (sample['group'], *[(k, 'MISSING' if isinstance(v, (float, np.floating)) and (not np.isfinite(v)) else v) for k, v in sorted(sample['features'].items()) if k != exclude])

def matched_response(state, predict, out, variable):
    """Vary dose/time only within each measured held-out series' own range."""
    field = 'log10_dose' if variable == 'dose' else 'log10_time'
    raw_key = 'dose' if variable == 'dose' else 'time_h'
    rows, observed_rows, summaries = ([], [], [])
    for j, eid in enumerate(HEADS):
        dev = [s for s in state['dev'] if s['mask'][j]]
        unique_dev = sorted({s[raw_key] for s in dev})
        grouped = defaultdict(list)
        for i, s in enumerate(state['internal']):
            if s['mask'][j]:
                grouped[feature_key(s, field)].append((i, s))
        series = []
        for key, items in grouped.items():
            levels = sorted({s[raw_key] for _, s in items})
            minimum = 3 if variable == 'dose' else 2
            if len(levels) < minimum:
                continue
            ss = sorted(items, key=lambda item: item[1][raw_key])
            low, high = (max(levels[0], unique_dev[0]), min(levels[-1], unique_dev[-1]))
            if low <= 0 or high <= low:
                continue
            series.append((ss, low, high))
        if len(unique_dev) < 2 or not series:
            reason = 'Only 24 h in endpoint training data' if len(unique_dev) < 2 else 'No matched multi-time held-out series' if variable == 'time' else 'No matched dose series'
            summaries.append({'endpoint': eid, 'status': 'not_estimable', 'reason': reason, 'training_unique_values': unique_dev})
            continue
        curves, changes, monotonic, ranks = ([], [], [], [])
        all_virtual = []
        for items, low, high in series:
            template = items[0][1]
            all_virtual.extend(({'features': dict(template['features'], **{field: float(np.log10(v))})} for v in np.geomspace(low, high, 11)))
        series_predictions = predict(all_virtual)[:, j].reshape(len(series), 11)
        for k, (items, low, high) in enumerate(series):
            template = items[0][1]
            grid = np.geomspace(low, high, 11)
            pp = series_predictions[k]
            curves.append(pp)
            changes.append(pp[-1] - pp[0])
            monotonic.append(bool(np.all(np.diff(pp) >= -1e-06)))
            original_dose = np.array([s[raw_key] for _, s in items])
            original_p = np.array([state['internal_ens'][i, j] for i, _ in items])
            rho = spearmanr(original_dose, original_p).statistic if np.ptp(original_p) > 1e-09 else np.nan
            ranks.append(rho)
            for step, (value, probability) in enumerate(zip(grid, pp)):
                rows.append({'endpoint': eid, 'series': k, 'material_group': template['group'], 'material': template['material'], 'cell': template['features']['cell_name'], 'variable': variable, 'value': value, 'within_series_log_position': step / 10, 'predicted_toxic_probability': probability})
            for i, s in items:
                observed_rows.append({'endpoint': eid, 'series': k, 'material_group': s['group'], 'sample_id': s['sample_id'], 'variable': variable, 'value': s[raw_key], 'actual': int(s['y'][j]), 'predicted_probability': state['internal_ens'][i, j]})
        curves = np.asarray(curves)
        group_curves = defaultdict(list)
        for (items, _, _), curve in zip(series, curves):
            group_curves[items[0][1]['group']].append(curve)
        material_curves = np.array([np.mean(v, axis=0) for v in group_curves.values()])
        x = np.linspace(0, 1, 11)
        lo, hi = np.quantile(material_curves, [0.1, 0.9], axis=0)
        summary = {'endpoint': eid, 'status': 'estimated', 'series_n': len(series), 'material_groups': len(group_curves), 'training_unique_values': unique_dev, 'series_high_above_low_fraction': float(np.mean(np.array(changes) > 1e-06)), 'series_nondecreasing_fraction': float(np.mean(monotonic)), 'median_observed_probability_spearman': float(np.nanmedian(ranks)), 'mean_probability_low_material_balanced': material_curves[:, 0].mean(), 'mean_probability_high_material_balanced': material_curves[:, -1].mean(), 'physical_low_range': [min((v[1] for v in series)), max((v[1] for v in series))], 'physical_high_range': [min((v[2] for v in series)), max((v[2] for v in series))]}
        summaries.append(summary)
        print(f'{variable} {eid}: {len(series)} matched series', flush=True)
    write_csv(out / f'{variable}_ice_curves.csv', rows)
    write_csv(out / f'{variable}_matched_observations.csv', observed_rows)
    write_json(out / f'{variable}_analysis_summary.json', summaries)
    return summaries

def grouped_shap(state, predict, out):
    rng = np.random.default_rng(SEED)
    groups = {'Dose': ['log10_dose'], 'Exposure time': ['log10_time'], 'Primary size': ['log10_particle_size'], 'Hydrodynamic size': ['log10_hydrodynamic_size'], 'Zeta potential': ['zeta_mv'], 'Composition': ['material_formula_norm', 'element_count', 'oxygen_fraction', 'metal_fraction'] + [f'el_{e}' for e in state['ELEMENTS']], 'Cell context': ['cell_name', 'species', 'organ'], 'Assay': ['assay']}
    assert sorted(sum(groups.values(), [])) == sorted(state['NUMERIC'] + state['CATEGORICAL'])
    group_names = list(groups)
    n_groups = len(groups)
    nm_ids = np.flatnonzero([s['mask'][0] for s in state['internal']])
    common = rng.choice(nm_ids, min(96, len(nm_ids)), replace=False)
    selected_by_head = {0: common, 2: common}
    all_e2 = np.flatnonzero([s['mask'][1] for s in state['internal']])
    selected_by_head[1] = rng.choice(all_e2, min(96, len(all_e2)), replace=False)
    backgrounds, shap_results, audit, rows = ({}, {}, {}, [])
    for j, eid in enumerate(HEADS):
        eligible = [s for s in state['dev'] if s['mask'][j]]
        by_material = defaultdict(list)
        for s in eligible:
            by_material[s['group']].append(s)
        material_ids = list(by_material)
        donors = [by_material[g][rng.integers(len(by_material[g]))] for g in rng.choice(material_ids, 16, replace=True)]
        backgrounds[j] = donors
        explained_ids = selected_by_head[j]
        totals = np.zeros((len(explained_ids), n_groups))
        pair_values = []
        base = predict(donors)[:, j].mean()
        for pair in range(8):
            pair_total = np.zeros_like(totals)
            for offset in range(2):
                donor = donors[2 * pair + offset]
                batch, paths = ([], [])
                for i in explained_ids:
                    target = state['internal'][i]
                    order = rng.permutation(n_groups)
                    for perm in (order, order[::-1]):
                        current = donor['features'].copy()
                        batch.append({'features': current.copy()})
                        for g in perm:
                            for field in groups[group_names[g]]:
                                current[field] = target['features'][field]
                            batch.append({'features': current.copy()})
                        paths.append(perm)
                pp = predict(batch)[:, j].reshape(len(explained_ids), 2, n_groups + 1)
                for k in range(len(explained_ids)):
                    for direction in range(2):
                        diff = np.diff(pp[k, direction])
                        perm = paths[k * 2 + direction]
                        pair_total[k, perm] += diff / 4
            totals += pair_total / 8
            pair_values.append(pair_total)
            print(f'Grouped SHAP {eid}: paired background block {pair + 1}/8', flush=True)
        target_prob = state['internal_ens'][explained_ids, j]
        error = np.max(np.abs(base + totals.sum(axis=1) - target_prob))
        assert error < 2e-05, (eid, error)
        se = np.std(pair_values, axis=0, ddof=1) / np.sqrt(8)
        shap_results[j] = totals
        for k, i in enumerate(explained_ids):
            s = state['internal'][i]
            for g, name in enumerate(group_names):
                rows.append({'endpoint': eid, 'sample_id': s['sample_id'], 'material_group': s['group'], 'actual': int(s['y'][j]), 'predicted_probability': target_prob[k], 'base_probability': base, 'feature_group': name, 'shap_probability_contribution': totals[k, g], 'monte_carlo_se': se[k, g]})
        importance = np.mean(np.abs(totals), axis=0)
        first_half = np.mean(np.abs(np.mean(pair_values[:4], axis=0)), axis=0)
        second_half = np.mean(np.abs(np.mean(pair_values[4:], axis=0)), axis=0)
        audit[eid] = {'explained_n': len(explained_ids), 'positive_n': int(sum((state['internal'][i]['y'][j] for i in explained_ids))), 'background_n': len(donors), 'background_unique_materials': len({s['group'] for s in donors}), 'background_sample_ids': [s['sample_id'] for s in donors], 'base_probability': base, 'max_additivity_error': error, 'mean_monte_carlo_se': float(se.mean()), 'split_half_importance_rank_spearman': spearmanr(first_half, second_half).statistic, 'importance': dict(zip(group_names, importance)), 'top_groups': [group_names[k] for k in np.argsort(-importance)[:3]]}
    write_csv(out / 'grouped_shap_values.csv', rows)
    write_json(out / 'grouped_shap_audit.json', {'method': 'Custom Monte Carlo interventional grouped Shapley; complete forward/reverse permutations, 16 training-only donors, 32 paths per observation', 'explained_model': 'full five-fold learned-weight RF/MLP/HGNN ensemble on probability scale', 'feature_groups': groups, 'seed': SEED, 'endpoints': audit, 'limits': ['96 uniformly sampled internal conditions per head, not the full test set; 16 material-balanced development background draws.', 'Chemistry-derived fields and cell/species/organ are kept together. Remaining dependencies may still produce off-manifold combinations.', 'Endpoint-specific backgrounds mean absolute SHAP magnitudes across heads use different references.', 'Monte Carlo approximation and feature attribution, not causal effects or proof of biological mechanism.']})
    return audit
