"""Recompute metrics/MCP curves from fixed predictions, without fitting models."""
import argparse
import csv
import gzip
from collections import defaultdict
from pathlib import Path
import numpy as np
from postfit import metric, write_csv
from sklearn.metrics import accuracy_score, balanced_accuracy_score, matthews_corrcoef

def read_rows(path):
    opener=gzip.open if str(path).endswith('.gz') else open
    with opener(path,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def summarize(rows,alpha):
    y=np.array([int(r['actual']) for r in rows]);p=np.array([float(r.get('ensemble_probability',r.get('score'))) for r in rows])
    result={'n':len(rows),**metric(y,p)}
    if rows and 'p_non_toxic' in rows[0]:
        pv=np.array([[float(r['p_non_toxic']),float(r['p_toxic'])] for r in rows]);inc=pv>alpha
        single=inc.sum(1)==1
        result.update(alpha=alpha,retained_n=int(single.sum()),retention=float(single.mean()),label_coverage=float(inc[np.arange(len(y)),y].mean()),empty_fraction=float((inc.sum(1)==0).mean()),two_label_fraction=float((inc.sum(1)==2).mean()))
        selected=metric(y[single],p[single]) if single.any() else {k:np.nan for k in metric(y,p)}
        if single.any():
            labels=inc[single].argmax(axis=1);truth=y[single];both=len(np.unique(truth))==2
            selected['accuracy']=accuracy_score(truth,labels)
            selected['balanced_accuracy']=balanced_accuracy_score(truth,labels) if both else np.nan
            selected['mcc']=matthews_corrcoef(truth,labels) if both and len(np.unique(labels))==2 else np.nan
        result.update({'singleton_'+k:v for k,v in selected.items()})
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('input');parser.add_argument('output');parser.add_argument('--bootstrap',type=int,default=0);parser.add_argument('--alpha',type=float,default=.1);parser.add_argument('--curve',action='store_true');parser.add_argument('--pool-sources',action='store_true');args=parser.parse_args()
    if not 0<=args.alpha<=1 or args.bootstrap<0:parser.error('Invalid alpha/bootstrap')
    rows=read_rows(args.input);rows=[r for r in rows if r['actual'] in ('0','1')];groups=defaultdict(list)
    if not rows:parser.error('No binary-labeled records')
    keys=[k for k in ('role','source','type','domain','endpoint','endpoint_id','model') if k in rows[0]]
    if args.pool_sources and 'source' in keys:keys.remove('source')
    for r in rows:groups[tuple(r[k] for k in keys)].append(r)
    output=[];rng=np.random.default_rng(20260916)
    for key,items in groups.items():
        members=defaultdict(list)
        for i,r in enumerate(items):members[r['group']].append(i)
        names=list(members)
        # Reuse cluster resamples across alpha; predictions/calibration stay fixed.
        draws=[np.concatenate([members[names[i]] for i in rng.integers(len(names),size=len(names))]) for _ in range(args.bootstrap)]
        for alpha in (np.linspace(0,1,101) if args.curve else [args.alpha]):
            point=summarize(items,float(alpha));row={**dict(zip(keys,key)),**point}
            if draws:
                stats=[summarize([items[i] for i in draw],float(alpha)) for draw in draws]
                for m in ('accuracy','balanced_accuracy','mcc','roc_auc','pr_auc','singleton_accuracy','singleton_balanced_accuracy','singleton_mcc','singleton_roc_auc','singleton_pr_auc','retention','label_coverage'):
                    if m not in point:continue
                    vals=np.array([s[m] for s in stats]);vals=vals[np.isfinite(vals)]
                    lo,hi=np.quantile(vals,[.16,.84]) if len(vals) else (np.nan,np.nan)
                    row[m+'_p16']=lo;row[m+'_p84']=hi;row[m+'_valid_repetitions']=len(vals)
            output.append(row)
    Path(args.output).parent.mkdir(parents=True,exist_ok=True);write_csv(Path(args.output),output)

if __name__=='__main__':main()
