import fs from 'node:fs';
import zlib from 'node:zlib';
import readline from 'node:readline';
import {decodeModel,parseCSV,predictRow,predictFeatures,featureRow,conformal,optimize,toCSV} from './engine.js';

const model=decodeModel(zlib.gunzipSync(fs.readFileSync(new URL('../model/model.json.gz',import.meta.url))).toString('utf8'));
const meta=JSON.parse(fs.readFileSync(new URL('../model/study.json',import.meta.url)));
const [command,input,output,alphaArg]=process.argv.slice(2);
const alpha=alphaArg===undefined?0.1:Number(alphaArg);
if(command==='serve'){
  // JSON-lines bridge: no network service, authentication, or remote calls.
  for await(const line of readline.createInterface({input:process.stdin})){
    try{
      const req=JSON.parse(line);
      let result;
      if(req.op==='features')result=req.rows.map(r=>featureRow(r,model));
      else if(req.op==='predict')result=req.features.map(f=>predictFeatures(f,model).scores);
      else if(req.op==='metadata')result={numeric:model.numeric,categorical:model.categorical,elements:model.elements,weights:model.weights};
      else throw Error('Unknown operation');
      process.stdout.write(JSON.stringify({result})+'\n');
    }catch(e){process.stdout.write(JSON.stringify({error:e.message})+'\n');}
  }
}else if(command==='predict'){
  if(!input||!output)throw Error('Usage: node src/run.mjs predict input.csv output.csv [alpha]');
  const rows=parseCSV(fs.readFileSync(input,'utf8'));
  const result=rows.flatMap((r,i)=>{const p=predictRow(r,model,meta,alpha,i);return p.scores.map((score,j)=>({sample_id:p.sample_id,endpoint:`E${j+1}`,probability:score,predicted_class:Number(score>=0.5),p_non_toxic:p.mcp[j].p_non_toxic,p_toxic:p.mcp[j].p_toxic,mcp_set:JSON.stringify(p.mcp[j].set),warnings:p.warnings.join(' | ')}));});
  fs.writeFileSync(output,toCSV(result));
}else if(command==='optimize'){
  if(!input||!output)throw Error('Usage: node src/run.mjs optimize CeO2 output.json');
  const spaces=JSON.parse(fs.readFileSync(new URL('../model/design-space.json',import.meta.url)));
  fs.writeFileSync(output,JSON.stringify(optimize({formula:input},model,spaces,meta),null,2));
}else if(command==='metadata'){
  console.log(JSON.stringify({version:model.version,numeric:model.numeric,categorical:model.categorical,elements:model.elements,weights:model.weights,calibrationPoolSizes:Object.fromEntries(Object.entries(model.calibration).map(([k,v])=>[k,Object.fromEntries(Object.entries(v).map(([cls,a])=>[cls,a.length]))]))},null,2));
}else{
  throw Error('Commands: predict, optimize, metadata, serve');
}
