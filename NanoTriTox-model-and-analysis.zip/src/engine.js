// Exact frozen RF leaf-head + MLP + fixed-context heterogeneous GNN inference.
// No training, remote prediction API, or example-score substitution.
const aliases={silica:'SiO2',silicondioxide:'SiO2',titania:'TiO2',titaniumdioxide:'TiO2',zincoxide:'ZnO',ceriumoxide:'CeO2',ceria:'CeO2',ironoxide:'FeOx',carbontubes:'C',carbonnanotubes:'C',carbonnp:'C',dendrimer:'C',chitosan:'C6H11NO4',polystyrene:'C8H8',hydroxyapatite:'Ca10P6O26H2',plga:'C5H8O5',sln:'C',qds:'CdSe',silver:'Ag',gold:'Au'};
const sigmoid=x=>x>=0?1/(1+Math.exp(-x)):Math.exp(x)/(1+Math.exp(x));
const finite=v=>v!==null&&v!==undefined&&String(v).trim()!==''&&Number.isFinite(Number(v));
export function decodeModel(text){return JSON.parse(text,(_key,v)=>{if(!v||typeof v!=='object'||!v.$array)return v;const binary=atob(v.$array),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0)),view=new DataView(bytes.buffer),size=v.dtype==='<f8'?8:4;if(!['<f8','<f4','<i4'].includes(v.dtype))throw Error('Unsupported model numeric format');const a=[];for(let i=0;i<bytes.length;i+=size)a.push(v.dtype==='<f8'?view.getFloat64(i,true):v.dtype==='<f4'?view.getFloat32(i,true):view.getInt32(i,true));if(v.shape.length===1)return a;if(v.shape.length===2)return Array.from({length:v.shape[0]},(_,i)=>a.slice(i*v.shape[1],(i+1)*v.shape[1]));throw Error('Unsupported model array shape');});}
export const fields=['sample_id','material_formula','dose_ug_ml','exposure_time_h','particle_size_nm','hydrodynamic_size_nm','zeta_mv','cell_name','species','organ','assay'];
export function normalizeFormula(s){let raw=String(s??'').trim().replace(/[₀-₉]/g,d=>'0123456789'['₀₁₂₃₄₅₆₇₈₉'.indexOf(d)]),low=raw.toLowerCase().replaceAll(' ','');for(const [k,v] of Object.entries(aliases))if(low.includes(k))return v;return raw;}
export function validateRow(row,index=0){
 if(!row||typeof row!=='object'||Array.isArray(row))throw Error(`Row ${index+1} must be a record.`);
 const r={};for(const k of fields)r[k]=String(row[k]??'').trim();
 if(!r.sample_id)r.sample_id=`sample-${index+1}`;
 if(r.sample_id.length>100)throw Error(`The sample ID in row ${index+1} is too long.`);
 r.material_formula=normalizeFormula(r.material_formula);
 if(!r.material_formula||r.material_formula.length>80||!/[A-Za-z]/.test(r.material_formula)||!/^[A-Za-z0-9\s()./+_−-]+$/.test(r.material_formula))throw Error(`The material formula in row ${index+1} is missing or unsupported.`);
 for(const k of ['dose_ug_ml','exposure_time_h'])if(!finite(r[k])||Number(r[k])<=0||Number(r[k])>100000)throw Error(`${k} in row ${index+1} must be a positive number between 0 and 100000 in the original physical unit.`);
 for(const k of ['particle_size_nm','hydrodynamic_size_nm'])if(r[k]&&(!finite(r[k])||Number(r[k])<=0||Number(r[k])>100000))throw Error(`${k} in row ${index+1} must be positive; leave it blank if unavailable.`);
 if(r.zeta_mv&&(!finite(r.zeta_mv)||Math.abs(Number(r.zeta_mv))>1000))throw Error(`The zeta potential in row ${index+1} has an unsupported format or range.`);
 for(const k of ['cell_name','species','organ','assay']){if(r[k].length>150)throw Error(`${k} in row ${index+1} is too long.`);if(!r[k])r[k]='UNKNOWN';}
 return r;
}
export function featureRow(row,model){
 const formula=normalizeFormula(row.material_formula),counts=Object.fromEntries(model.elements.map(x=>[x,0]));
 for(const [,el,amount] of formula.matchAll(/([A-Z][a-z]?)(\d*(?:\.\d+)?)/g))if(el in counts)counts[el]+=amount?Number(amount):1;
 const total=Object.values(counts).reduce((a,b)=>a+b,0),f={material_formula_norm:formula,zeta_mv:finite(row.zeta_mv)?Number(row.zeta_mv):null,element_count:Object.values(counts).filter(x=>x>0).length,oxygen_fraction:total?counts.O/total:0,metal_fraction:total?(total-counts.O-counts.C-counts.S)/total:0};
 for(const [dst,src] of [['log10_dose','dose_ug_ml'],['log10_time','exposure_time_h'],['log10_particle_size','particle_size_nm'],['log10_hydrodynamic_size','hydrodynamic_size_nm']])f[dst]=finite(row[src])?Math.log10(Math.max(Number(row[src]),1e-9)):null;
 for(const e of model.elements)f[`el_${e}`]=counts[e];for(const k of ['cell_name','species','organ','assay'])f[k]=row[k]||'UNKNOWN';return f;
}
function encode(f,model,prep){
 const missing=model.numeric.map(k=>!finite(f[k]));const n=model.numeric.map((k,i)=>missing[i]?prep.median[i]:Number(f[k]));
 for(const i of prep.indicators)n.push(missing[i]?1:0);
 const x=n.map((v,i)=>Math.fround((v-prep.mean[i])/prep.scale[i]));
 for(let j=0;j<prep.cats.length;j++){const c=prep.cats[j],start=x.length;for(let i=0;i<c.size;i++)x.push(0);const idx=c.map[String(f[model.categorical[j]])];if(idx!==undefined&&idx>=0)x[start+idx]=1;}
 return x;
}
function linear(x,layer,relu=false){const out=[];for(let j=0;j<layer.w.length;j++){const w=layer.w[j];let sum=layer.b[j];for(let k=0;k<w.length;k++)sum+=w[k]*x[k];sum=Math.fround(sum);out.push(relu?Math.max(0,sum):sum);}return out;}
function headProbs(x,heads){return heads.map(h=>sigmoid(linear(x,h)[0]));}
export function predictFeatures(f,model){
 const means=Array.from({length:3},()=>[0,0,0]);
 for(const fold of model.folds){
  const x=encode(f,model,fold.preprocess),logits=[...fold.rf.intercept];
  for(const t of fold.rf.trees){let node=0;while(t.left[node]!==-1)node=x[t.feature[node]]<=t.threshold[node]?t.left[node]:t.right[node];for(let j=0;j<3;j++)logits[j]+=t.scores[node][j];}
  const rf=logits.map(sigmoid);let h=x;for(const layer of fold.mlp.layers)h=linear(h,layer,true);const mlp=headProbs(h,fold.mlp.heads);
  let gh=linear(x,fold.gnn.obs,true);for(const entity of fold.gnn.entities)gh=gh.concat(entity.values[entity.vocab[String(f[entity.field])]??0]);
  const gnn=headProbs(linear(gh,fold.gnn.mix,true),fold.gnn.heads);
  for(let branch=0;branch<3;branch++)for(let j=0;j<3;j++)means[branch][j]+=[rf,mlp,gnn][branch][j]/model.folds.length;
 }
 return {scores:[0,1,2].map(j=>means.reduce((sum,b,k)=>sum+b[j]*model.weights[j][k],0)),branches:means};
}
export function conformal(scores,model,alpha=.1){
 if(!Number.isFinite(alpha)||alpha<0||alpha>1)throw Error('The significance level α must be between 0 and 1.');
 return scores.map((s,j)=>{const pv=[0,1].map(cls=>{const a=model.calibration[j][cls],value=cls?1-s:s;return(1+a.filter(x=>x>=value).length)/(a.length+1);});return {p_non_toxic:pv[0],p_toxic:pv[1],set:[0,1].filter(cls=>pv[cls]>alpha)};});
}
export function predictRow(input,model,meta,alpha=.1,index=0){
 const row=validateRow(input,index),f=featureRow(row,model),p=predictFeatures(f,model),mcp=conformal(p.scores,model,alpha),warnings=[];
 const knownCategory=(field,value)=>{const j=model.categorical.indexOf(field);return j>=0&&model.folds.some(fold=>Object.hasOwn(fold.preprocess.cats[j].map,String(value)));};
 if(f.cell_name!=='HepaRG'||Math.abs(Number(row.exposure_time_h)-24)>1e-6)warnings.push('E1/E3 are outside their HepaRG, 24 h training conditions; these heads are extrapolations.');
 if(!meta.formulas.includes(f.material_formula_norm))warnings.push('This composition was not represented in the development data; the prediction is a composition extrapolation.');
 if(!meta.cells.includes(f.cell_name))warnings.push('This cell line was not represented in the development data.');
 if(!meta.assays.includes(f.assay))warnings.push('This assay was not represented in the development data.');
 if(!knownCategory('species',f.species))warnings.push('This species label was not represented in the development data and is encoded as unknown.');
 if(!knownCategory('organ',f.organ))warnings.push('This organ or tissue label was not represented in the development data and is encoded as unknown.');
 if(Number(row.dose_ug_ml)<.001||Number(row.dose_ug_ml)>1000||Number(row.exposure_time_h)<.5||Number(row.exposure_time_h)>360)warnings.push('Dose or exposure time is outside the overall development-data range.');
 if(Number(row.dose_ug_ml)<.48828125||Number(row.dose_ug_ml)>250)warnings.push('Dose is outside the E1/E3 development range (0.488–250 μg/mL).');
 if(['particle_size_nm','hydrodynamic_size_nm','zeta_mv'].some(k=>!finite(row[k])))warnings.push('Some physicochemical features are missing and are imputed with training-fold medians.');
 const untracked=[...f.material_formula_norm.matchAll(/([A-Z][a-z]?)/g)].map(m=>m[1]).filter(e=>!model.elements.includes(e));
 if(untracked.length)warnings.push(`The frozen model does not fully encode these elements: ${[...new Set(untracked)].join(', ')}.`);
 if(/[()/]/.test(f.material_formula_norm))warnings.push('Complex compositions use the frozen model\'s approximate formula encoding; bracket multipliers and core-shell structures are not parsed.');
 return {sample_id:row.sample_id,input:row,scores:p.scores,branches:p.branches,mcp,alpha,warnings};
}
export function parseCSV(text){
 text=String(text).replace(/^\uFEFF/,'');const lines=[];let cells=[],value='',quoted=false;
 for(let i=0;i<text.length;i++){let ch=text[i];if(ch==='"'){if(quoted&&text[i+1]==='"'){value+='"';i++;}else if(!quoted&&value!=='')throw Error('Invalid CSV quote format.');else quoted=!quoted;}else if(ch===','&&!quoted){cells.push(value);value='';}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&text[i+1]==='\n')i++;cells.push(value);if(cells.some(x=>x.trim()))lines.push(cells);cells=[];value='';}else value+=ch;}
 if(quoted)throw Error('The CSV contains an unclosed quote.');cells.push(value);if(cells.some(x=>x.trim()))lines.push(cells);
 if(lines.length<2)throw Error('Enter at least one data row below the template header.');const header=lines.shift().map(x=>x.trim());if(new Set(header).size!==header.length)throw Error('CSV headers must be unique.');
 for(const k of ['material_formula','dose_ug_ml','exposure_time_h'])if(!header.includes(k))throw Error(`Missing required column: ${k}`);
 if(lines.length>250)throw Error('A batch may contain at most 250 conditions. Split larger files.');
 const rows=lines.map((line,i)=>{if(line.length!==header.length)throw Error(`Row ${i+2} has a different number of columns from the header.`);return validateRow(Object.fromEntries(header.map((k,j)=>[k,line[j]])),i);});
 if(new Set(rows.map(r=>r.sample_id)).size!==rows.length)throw Error('sample_id values must be unique.');return rows;
}
export function toCSV(rows){if(!rows.length)return '';const keys=Object.keys(rows[0]);const cell=x=>{let s=String(x??'');if(/^[=+@\t\r]/.test(s)||(/^\s*-/.test(s)&&!Number.isFinite(Number(s))))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};return '\uFEFF'+[keys,...rows.map(r=>keys.map(k=>r[k]))].map(r=>r.map(cell).join(',')).join('\r\n');}
const quantile=(arr,p)=>{const s=[...arr].sort((a,b)=>a-b),i=(s.length-1)*p,a=Math.floor(i);return s[a]+(s[Math.ceil(i)]-s[a])*(i-a);};
const distance=(a,b,scale)=>Math.sqrt(a.reduce((s,v,j)=>s+((v-b[j])/scale[j])**2,0));
export function optimize(options,model,spaces,meta,onProgress=()=>{}){
 const pool=spaces[options.formula];if(!pool)throw Error('This composition lacks enough complete physicochemical descriptors for constrained screening.');
 const doses=options.doses??[31.25,62.5,125];if(!Array.isArray(doses)||doses.length!==3||doses.some(v=>!Number.isFinite(Number(v))||Number(v)<.48828125||Number(v)>250))throw Error('Enter three doses between 0.488 and 250 μg/mL.');
 const doseValues=doses.map(Number);if(new Set(doseValues).size!==3)throw Error('The three doses must be different.');doseValues.sort((a,b)=>a-b);
 const alpha=options.alpha??.1;if(!Number.isFinite(alpha)||alpha<0||alpha>1)throw Error('α must be between 0 and 1.');
 const z=pool.profiles.map(p=>p.values),scale=[0,1,2].map(j=>{const a=z.map(v=>v[j]);return quantile(a,.75)-quantile(a,.25)||1;});
 const nearest=z.map((v,i)=>Math.min(...z.filter((_,j)=>i!==j).map(w=>distance(v,w,scale)))),ad=Math.max(.1,quantile(nearest,.95));
 const ref=[Math.log10(pool.reference.primary_size_nm),Math.log10(pool.reference.hydrodynamic_size_nm),pool.reference.zeta_mv];
 const candidates=new Map(),key=v=>v.map(x=>x.toFixed(8)).join('|');for(const p of pool.profiles)candidates.set(key(p.values),{z:p.values,kind:'observed',parents:[p.id]});
 for(let i=0;i<z.length;i++)for(let j=i+1;j<z.length;j++)for(const frac of [.25,.5,.75]){const v=z[i].map((x,k)=>(1-frac)*x+frac*z[j][k]);if(v[1]>=v[0]&&!candidates.has(key(v)))candidates.set(key(v),{z:v,kind:'interpolated',parents:[pool.profiles[i].id,pool.profiles[j].id]});}
 const bounds=options.bounds??{};for(const name of ['particle_size_nm','hydrodynamic_size_nm','zeta_mv'])if(bounds[name]){const a=bounds[name];if(!Array.isArray(a)||a.length!==2||a.some(x=>!Number.isFinite(x))||a[0]>a[1])throw Error(`Invalid screening bounds for ${name}.`);}
 const rows=[];let index=0;
 for(const [k,c] of candidates){
  const values=[10**c.z[0],10**c.z[1],c.z[2]],isReference=k===key(ref),adDistance=Math.min(...z.map(v=>distance(c.z,v,scale)));
  const allowed=adDistance<=ad+1e-10&&['particle_size_nm','hydrodynamic_size_nm','zeta_mv'].every((name,j)=>!bounds[name]||(values[j]>=bounds[name][0]&&values[j]<=bounds[name][1]));
  if(!allowed&&!isReference){index++;continue;}
  const predictions=doseValues.map(dose=>predictRow({...pool.template,sample_id:`${options.formula}-${index}`,dose_ug_ml:dose,exposure_time_h:24,particle_size_nm:values[0],hydrodynamic_size_nm:values[1],zeta_mv:values[2]},model,meta,alpha));
  const risk=[0,1,2].map(j=>Math.max(...predictions.map(p=>p.scores[j])));
  rows.push({id:`${options.formula}-${index}`,formula:options.formula,particle_size_nm:values[0],hydrodynamic_size_nm:values[1],zeta_mv:values[2],kind:c.kind,parents:c.parents,scores:risk,worst:Math.max(...risk),change:distance(c.z,ref,scale),ad_distance:adDistance,ad_threshold:ad,eligible:allowed,reference:isReference,predictions,all_nine_mcp_low:predictions.every(p=>p.mcp.every(m=>m.set.length===1&&m.set[0]===0))});
  index++;if(index%8===0)onProgress(index/candidates.size);
 }
 const reference=rows.find(r=>r.reference);if(!reference)throw Error('The reference descriptor combination could not be located.');
 for(const r of rows)if(options.noWorsening&&r.scores.some((x,j)=>x>reference.scores[j]+1e-10))r.eligible=false;
 const eligible=rows.filter(r=>r.eligible);if(!eligible.length)throw Error('No candidates satisfy the constraints. Broaden the physicochemical descriptor ranges.');
 for(const r of rows){const a=[...r.scores,r.change];r.pareto=r.eligible&&!eligible.some(q=>{const b=[...q.scores,q.change];return b.every((x,j)=>x<=a[j]+1e-10)&&b.some((x,j)=>x<a[j]-1e-10);});}
 eligible.sort((a,b)=>a.worst-b.worst||a.change-b.change);onProgress(1);
 return {formula:options.formula,doses:doseValues,alpha,reference,selected:eligible[0],candidates:rows,candidate_count:candidates.size,eligible_count:eligible.length,all_nine_mcp_low_count:eligible.filter(r=>r.all_nine_mcp_low).length,noWorsening:!!options.noWorsening};
}
