# NanoTriTox

Frozen models and post-fit numerical analysis for heterogeneous graph neural network-based ensemble prediction of nanomaterial toxicity.

The three outputs are E1 (reduced viable cell count), E2 (reduced cell viability), and E3 (mitochondrial membrane potential loss). This repository is an **inference-only release**: no model training, ensemble-weight fitting, or plotting code is included. The already learned combination is part of the saved model and is applied during inference; it is not re-estimated.

## Quick start

Install Node.js 22 or later. The prediction engine has no npm dependencies and runs locally, without contacting a prediction server.

```sh
git clone https://github.com/weikaixi/NanoTriTox.git
cd NanoTriTox
node tests/smoke.mjs
node src/run.mjs predict examples/prediction_example.csv predictions.csv
node src/run.mjs optimize CeO2 optimization.json
node src/run.mjs metadata
```

`model/model.json.gz` is the complete frozen inference bundle, not example output. It contains five fitted folds, preprocessing parameters, RF leaf-head coefficients, neural-network parameters, fixed training-derived graph context embeddings, endpoint-specific weights, and frozen class-conditional MCP calibration scores. It does not require access to the original training scripts or raw graph-context records. Typed numeric arrays preserve the exported parameter precision.

Model SHA-256: `2be8dd4b2caf121f9db6cdd99d48a7a1d526836d01fb6541aa088bf18e5e0bc5`.

## Input and output

Use `examples/prediction_template.csv`. Required columns are `material_formula`, `dose_ug_ml`, and `exposure_time_h`. Optional columns are `sample_id`, `particle_size_nm`, `hydrodynamic_size_nm`, `zeta_mv`, `cell_name`, `species`, `organ`, and `assay`. Use original physical units, not log-transformed values. The CSV interface accepts up to 250 records per batch.

Dose, duration, and sizes are log-transformed. Missing numeric descriptors use saved fold-specific medians. Material formula supplies both categorical identity and approximate elemental descriptors. Cell/species/organ/assay strings use the frozen categorical vocabulary; novel categories do not create learned embeddings. Known values are listed in `model/study.json`. Formula parsing is approximate: parenthetical stoichiometry, coating, morphology, dissolution, and core-shell structure are not fully represented. Do not interpret a syntactically accepted formula as evidence of applicability.

Outputs contain probabilities, fixed-threshold classes, class-specific conformal p-values, prediction sets, and applicability warnings. A probability is a model score, not a measured percentage of injured cells. E1/E3 modeling data are HepaRG at 24 h; predictions outside that context are extrapolations.

An optional fourth argument to `predict` changes alpha (default 0.10):

```sh
node src/run.mjs predict examples/prediction_example.csv predictions.csv 0.10
```

MCP retains label c when p(c) > alpha. At alpha=0 all sets contain both labels; at alpha=1 all sets are empty. Report singleton performance with retention and coverage, never as performance of all submitted records. Cross-conformal pooling and external distribution shift do not provide an unconditional finite-sample coverage guarantee.

## Data access and numerical analyses

The standardized study datasets are available from the [public platform](https://nanotritox.cpmlab.cn), under Study data. This release does not redistribute the original publications or all source datasets. Their original terms and attribution requirements continue to apply.

There are two modeling collections (6,925 records: development 5,541; locked internal test 1,384) and five external collections (5,360 endpoint-specific records). HARMLESS supports E1 and E2, so the external collections yield six dataset-endpoint evaluations. The 8,705 modeling endpoint labels are not 8,705 independent records.

For Python analyses, install the dependencies in a virtual environment:

```sh
python -m pip install -r requirements.txt
python src/evaluate.py reference/internal_predictions.csv.gz results/internal_metrics.csv --pool-sources
python src/evaluate.py reference/external_predictions.csv.gz results/external_mcp.csv
python src/evaluate.py reference/external_predictions.csv.gz results/external_curves.csv --curve --bootstrap 500
python src/evaluate.py reference/baseline_predictions.csv.gz results/baselines.csv
python src/evaluate.py reference/domain_predictions.csv.gz results/domain_metrics.csv
```

The reference tables contain fixed scientific predictions used in the study. `evaluate.py` recomputes metrics without refitting. Its optional 500 material-group bootstrap repetitions hold predictions and calibration fixed and report 16th/84th percentiles (68% intervals), excluding undefined statistics. The random seed is 20260916; this reimplementation can differ in bootstrap endpoints from historical figures because its resampling sequence is newly specified. Point estimates should match. MCC is reported as undefined when either true or predicted classes lack variation, matching the study convention. Retained MCC uses the fixed 0.5 score threshold within singleton-selected records.

Download `development_oof.csv` and `internal_test.csv` from the platform into `inputs/`, preserving row order and supplied labels/group identifiers, then run:

```sh
python src/interpret.py dose inputs/development_oof.csv inputs/internal_test.csv results/dose
python src/interpret.py time inputs/development_oof.csv inputs/internal_test.csv results/time
python src/interpret.py shap inputs/development_oof.csv inputs/internal_test.csv results/shap
```

Set `NANOTRITOX_NODE` to the Node executable if it is not on PATH. These analyses call the same frozen model through a local JSON-lines subprocess. Full grouped SHAP can take substantial CPU time. The numerical SHAP and matched-response functions were extracted from the study scripts with plotting removed: 96 internal records per head, 16 material-balanced development donors, 32 forward/reverse paths per record, seed 20260906. Attribution is on the probability scale, with composition-derived and cell-context fields kept together. This is approximate interventional grouped Shapley attribution, not TreeSHAP or causal inference.

Dose/time analyses vary one exposure variable within a matched held-out series' observed range and the development range. All other inputs remain fixed; dose needs at least three distinct observed levels and time at least two. The aggregate gives each material group equal weight. E1/E3 temporal effects are not estimable from their single-duration training data. The model is not forced to be monotonic.

## Main-figure correspondence

| Figure | Numerical content available here |
|---|---|
| 1 | Frozen architecture parameters and endpoint weights (`metadata`); no fitting or schematic drawing |
| 2 | Internal/external and conventional-baseline metrics from fixed prediction tables |
| 3 | MCP selection, empirical label coverage, retention, and metric curves from fixed p-values |
| 4 | Metrics from saved independent material-/cell-held-out predictions; **these are not predictions from the final deployed model** |
| 5 | Grouped SHAP and matched dose/time analysis using the frozen model |
| 6 | Constrained material screening (`optimize`); website screenshots and drawing code excluded |

Separate domain-held-out refits and conventional-baseline fitting are intentionally not included. Their saved predictions support numerical re-evaluation, not reproduction of their training. This distinction prevents test-domain information from being introduced through the final deployed model.

## Material screening

Supported compositions: Au, CeO2, CeZrO2, SiO2, TiO2. The saved design space contains development-derived observed physicochemical profiles and the reference profiles. The engine generates within-composition interpolations, applies descriptor-support constraints, and compares candidates under identical HepaRG/24 h conditions at 31.25, 62.5, and 125 micrograms/mL. The scalar objective minimizes the maximum predicted risk across the three endpoints and three doses. Pareto status additionally considers the three worst-dose endpoint risks and normalized displacement from the reference.

Outputs include candidate descriptors, risks, reference/selected status, Pareto membership, support distances, and MCP sets. Lower predicted risk is not proof of safety, biological causality, synthesis feasibility, or preserved material function. Ordinary-test MCP coverage does not automatically carry over to prediction-selected candidates.

## Verification and reuse

`node tests/smoke.mjs` checks the model hash, numerical agreement against 33 original Python-model reference inputs, invalid-dose rejection, and both MCP boundaries. It does not claim that every figure was regenerated during packaging. Model parameters and calibration were not changed.

No license is assigned by this release. Public availability alone does not grant unrestricted reuse rights; contact the authors for licensing. Source-data terms remain with their respective providers. For manuscript citation, use this repository URL and the exact commit corresponding to the submitted version.
