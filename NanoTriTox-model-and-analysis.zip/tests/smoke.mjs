import fs from 'node:fs';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {decodeModel,predictRow,conformal,validateRow} from '../src/engine.js';
const bytes=fs.readFileSync(new URL('../model/model.json.gz',import.meta.url));
assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),'2be8dd4b2caf121f9db6cdd99d48a7a1d526836d01fb6541aa088bf18e5e0bc5');
const model=decodeModel(zlib.gunzipSync(bytes).toString('utf8'));
const meta=JSON.parse(fs.readFileSync(new URL('../model/study.json',import.meta.url)));
const cases=JSON.parse(fs.readFileSync(new URL('./reference.json',import.meta.url)));
let error=0;
for(const f of cases){const p=predictRow(f.input,model,meta).scores;for(let j=0;j<3;j++)error=Math.max(error,Math.abs(p[j]-f.expected[j]));}
assert.ok(error<2e-5);
assert.ok(conformal([0,.5,1],model,0).every(m=>m.set.length===2));
assert.ok(conformal([0,.5,1],model,1).every(m=>m.set.length===0));
assert.throws(()=>validateRow({...meta.example,dose_ug_ml:-1}));
console.log(JSON.stringify({status:'PASS',cases:cases.length,maxProbabilityError:error,mcpBoundaryTests:true}));
